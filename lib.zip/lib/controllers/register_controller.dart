import 'package:get/get.dart';
import '../services/register_service.dart';

enum RegisterStep { inputData, otp, setPassword, done }

class RegisterController extends GetxController {
  final RegisterService _service = RegisterService();

  var currentStep = RegisterStep.inputData.obs;
  var isLoading = false.obs;
  var errorMessage = ''.obs;
  var registrationToken = ''.obs;

  String _pendingOtp = '';

  Future<void> submitRegistration({
    required String noHp,
    required String tanggalLahir,
    required String namaOrangTua,
    required String namaAnak,
    required String tanggalLahirAnak,
    required String jenisKelaminAnak,
  }) async {
    try {
      isLoading.value = true;
      errorMessage.value = '';

      final token = await _service.register(
        noHp: noHp,
        tanggalLahir: tanggalLahir,
        namaOrangTua: namaOrangTua,
        namaAnak: namaAnak,
        tanggalLahirAnak: tanggalLahirAnak,
        jenisKelaminAnak: jenisKelaminAnak,
      );

      registrationToken.value = token;
      currentStep.value = RegisterStep.otp;
    } catch (e) {
      errorMessage.value = e.toString();
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> resendOtp() async {
    try {
      isLoading.value = true;
      await _service.resendOtp(registrationToken.value);
      Get.snackbar('Terkirim', 'Kode OTP baru telah dikirim ke WhatsApp.');
    } catch (e) {
      errorMessage.value = e.toString();
    } finally {
      isLoading.value = false;
    }
  }

  void proceedToSetPassword(String otp) {
    _pendingOtp = otp;
    currentStep.value = RegisterStep.setPassword;
  }

  Future<void> completeRegistration(String password) async {
    try {
      isLoading.value = true;
      errorMessage.value = '';

      await _service.verifyOtp(
        registrationToken: registrationToken.value,
        otp: _pendingOtp,
        password: password,
      );

      currentStep.value = RegisterStep.done;
    } catch (e) {
      errorMessage.value = e.toString();
      currentStep.value = RegisterStep.otp;
    } finally {
      isLoading.value = false;
    }
  }
}
