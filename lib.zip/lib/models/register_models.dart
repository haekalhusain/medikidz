class RegistrationResult {
  final String idUser;
  final String idAnak;

  RegistrationResult({required this.idUser, required this.idAnak});

  factory RegistrationResult.fromJson(Map<String, dynamic> json) {
    return RegistrationResult(idUser: json['id_user'], idAnak: json['id_anak']);
  }
}

class RegisterException implements Exception {
  final String message;
  RegisterException(this.message);

  @override
  String toString() => message;
}
