import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/register_models.dart';

/// Memanggil Cloud Functions (bukan Laravel) untuk proses registrasi + OTP.
/// GANTI baseUrl sesuai region & project Firebase kamu setelah deploy:
/// firebase deploy --only functions
class RegisterService {
  static const String baseUrl = 'https://REGION-PROJECT_ID.cloudfunctions.net';


  Future<String> register({
    required String noHp,
    required String tanggalLahir,
    required String namaOrangTua,
    required String namaAnak,
    required String tanggalLahirAnak,
    required String jenisKelaminAnak,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'no_hp': noHp,
        'tanggal_lahir': tanggalLahir,
        'nama_orang_tua': namaOrangTua,
        'nama_anak': namaAnak,
        'tanggal_lahir_anak': tanggalLahirAnak,
        'jenis_kelamin_anak': jenisKelaminAnak,
      }),
    );

    final body = jsonDecode(response.body);
    if (response.statusCode == 200 && body['success'] == true) {
      return body['data']['registration_token'];
    }
    throw RegisterException(body['message'] ?? 'Terjadi kesalahan.');
  }

  Future<void> resendOtp(String registrationToken) async {
    final response = await http.post(
      Uri.parse('$baseUrl/resendOtp'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'registration_token': registrationToken}),
    );
    final body = jsonDecode(response.body);
    if (response.statusCode != 200 || body['success'] != true) {
      throw RegisterException(body['message'] ?? 'Gagal mengirim ulang OTP.');
    }
  }

  Future<RegistrationResult> verifyOtp({
    required String registrationToken,
    required String otp,
    required String password,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/verifyOtp'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'registration_token': registrationToken,
        'otp': otp,
        'password': password,
      }),
    );

    final body = jsonDecode(response.body);
    if (response.statusCode == 201 && body['success'] == true) {
      return RegistrationResult.fromJson(body['data']);
    }
    throw RegisterException(body['message'] ?? 'Gagal membuat akun.');
  }
}
