import 'package:flutter/material.dart';
import 'vaksin/vaksin_list_page.dart';
import 'anak/anak_list_page.dart';
import 'anak/cari_akun_page.dart';
import 'jadwal_master/jadwal_master_list_page.dart';

class AdminDashboardPage extends StatelessWidget {
  const AdminDashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    final menus = [
      _MenuItem('Kelola Vaksin', Icons.vaccines, () {
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => const VaksinListPage()));
      }),
      _MenuItem('Data Anak', Icons.child_care, () {
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AnakListPage()));
      }),
      _MenuItem('Tambah Anak (akun ada)', Icons.person_add, () {
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CariAkunPage()));
      }),
      _MenuItem('Jadwal Master', Icons.medical_information, () {
        Navigator.of(context).push(MaterialPageRoute(builder: (_) => const JadwalMasterListPage()));
      }),
      _MenuItem('Kelola Pengguna', Icons.people, () => _comingSoon(context, 'Pengguna')),
      _MenuItem('Artikel Edukasi', Icons.article, () => _comingSoon(context, 'Artikel Edukasi')),
      _MenuItem('Jadwal & Riwayat', Icons.calendar_month, () => _comingSoon(context, 'Jadwal & Riwayat')),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Dashboard Admin')),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1.1,
        ),
        itemCount: menus.length,
        itemBuilder: (context, index) {
          final menu = menus[index];
          return Card(
            child: InkWell(
              onTap: menu.onTap,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(menu.icon, size: 36, color: Colors.teal),
                  const SizedBox(height: 8),
                  Text(menu.title, textAlign: TextAlign.center),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  void _comingSoon(BuildContext context, String name) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$name — ikuti pattern modul Vaksin/Anak untuk membuat ini.')),
    );
  }
}

class _MenuItem {
  final String title;
  final IconData icon;
  final VoidCallback onTap;
  _MenuItem(this.title, this.icon, this.onTap);
}
