import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../controllers/register_controller.dart';

class StepOtp extends StatefulWidget {
  final RegisterController controller;
  const StepOtp({super.key, required this.controller});

  @override
  State<StepOtp> createState() => _StepOtpState();
}

class _StepOtpState extends State<StepOtp> {
  final _otpController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final controller = widget.controller;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Kode OTP telah dikirim ke nomor WhatsApp yang kamu daftarkan.', style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 20),
        TextField(
          controller: _otpController,
          keyboardType: TextInputType.number,
          maxLength: 6,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 24, letterSpacing: 8),
          decoration: const InputDecoration(counterText: '', border: OutlineInputBorder()),
        ),
        Obx(() {
          if (controller.errorMessage.isNotEmpty) {
            return Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(controller.errorMessage.value, style: const TextStyle(color: Colors.red)),
            );
          }
          return const SizedBox.shrink();
        }),
        const SizedBox(height: 20),
        Obx(() => SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: controller.isLoading.value ? null : _submit,
                child: controller.isLoading.value
                    ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('Verifikasi'),
              ),
            )),
        const SizedBox(height: 12),
        Center(
          child: TextButton(
            onPressed: controller.isLoading.value ? null : controller.resendOtp,
            child: const Text('Kirim ulang kode OTP'),
          ),
        ),
      ],
    );
  }

  void _submit() {
    if (_otpController.text.length != 6) {
      widget.controller.errorMessage.value = 'Kode OTP harus 6 digit';
      return;
    }
    widget.controller.proceedToSetPassword(_otpController.text);
  }
}
