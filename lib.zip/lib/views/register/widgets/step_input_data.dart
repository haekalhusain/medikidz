import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../controllers/register_controller.dart';

class StepInputData extends StatefulWidget {
  final RegisterController controller;
  const StepInputData({super.key, required this.controller});

  @override
  State<StepInputData> createState() => _StepInputDataState();
}

class _StepInputDataState extends State<StepInputData> {
  final _formKey = GlobalKey<FormState>();
  final _noHpController = TextEditingController();
  final _namaOrangTuaController = TextEditingController();
  final _namaAnakController = TextEditingController();
  DateTime? _tanggalLahirOrtu;
  DateTime? _tanggalLahirAnak;
  String _jenisKelaminAnak = 'laki-laki';

  @override
  Widget build(BuildContext context) {
    final controller = widget.controller;

    return Form(
      key: _formKey,
      child: ListView(
        children: [
          const Text('Data Orang Tua', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 12),
          TextFormField(
            controller: _namaOrangTuaController,
            decoration: const InputDecoration(labelText: 'Nama Orang Tua', border: OutlineInputBorder()),
            validator: (v) => (v == null || v.isEmpty) ? 'Wajib diisi' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _noHpController,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
              labelText: 'Nomor WhatsApp',
              hintText: '08xxxxxxxxxx',
              border: OutlineInputBorder(),
            ),
            validator: (v) => (v == null || v.length < 10) ? 'Nomor HP tidak valid' : null,
          ),
          const SizedBox(height: 16),
          InkWell(
            onTap: () => _pickDate(isAnak: false),
            child: InputDecorator(
              decoration: const InputDecoration(labelText: 'Tanggal Lahir Orang Tua', border: OutlineInputBorder()),
              child: Text(_formatOrPlaceholder(_tanggalLahirOrtu)),
            ),
          ),
          const SizedBox(height: 24),
          const Text('Data Anak (Anak Pertama)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const Text(
            'Anak kedua dan seterusnya bisa ditambahkan admin klinik setelah akun ini aktif.',
            style: TextStyle(fontSize: 12, color: Colors.black54),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _namaAnakController,
            decoration: const InputDecoration(labelText: 'Nama Anak', border: OutlineInputBorder()),
            validator: (v) => (v == null || v.isEmpty) ? 'Wajib diisi' : null,
          ),
          const SizedBox(height: 16),
          InkWell(
            onTap: () => _pickDate(isAnak: true),
            child: InputDecorator(
              decoration: const InputDecoration(labelText: 'Tanggal Lahir Anak', border: OutlineInputBorder()),
              child: Text(_formatOrPlaceholder(_tanggalLahirAnak)),
            ),
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<String>(
            value: _jenisKelaminAnak,
            decoration: const InputDecoration(labelText: 'Jenis Kelamin Anak', border: OutlineInputBorder()),
            items: const [
              DropdownMenuItem(value: 'laki-laki', child: Text('Laki-laki')),
              DropdownMenuItem(value: 'perempuan', child: Text('Perempuan')),
            ],
            onChanged: (value) => setState(() => _jenisKelaminAnak = value!),
          ),
          const SizedBox(height: 24),
          Obx(() {
            if (controller.errorMessage.isNotEmpty) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: Text(controller.errorMessage.value, style: const TextStyle(color: Colors.red)),
              );
            }
            return const SizedBox.shrink();
          }),
          Obx(() => SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: controller.isLoading.value ? null : _submit,
                  child: controller.isLoading.value
                      ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Text('Lanjutkan'),
                ),
              )),
        ],
      ),
    );
  }

  String _formatOrPlaceholder(DateTime? date) {
    if (date == null) return 'Pilih tanggal';
    return '${date.day}/${date.month}/${date.year}';
  }

  Future<void> _pickDate({required bool isAnak}) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: isAnak ? DateTime(2020) : DateTime(1990),
      firstDate: DateTime(1970),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        if (isAnak) {
          _tanggalLahirAnak = picked;
        } else {
          _tanggalLahirOrtu = picked;
        }
      });
    }
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    if (_tanggalLahirOrtu == null || _tanggalLahirAnak == null) {
      widget.controller.errorMessage.value = 'Tanggal lahir wajib diisi lengkap';
      return;
    }

    widget.controller.submitRegistration(
      noHp: _noHpController.text.trim(),
      tanggalLahir: _isoDate(_tanggalLahirOrtu!),
      namaOrangTua: _namaOrangTuaController.text.trim(),
      namaAnak: _namaAnakController.text.trim(),
      tanggalLahirAnak: _isoDate(_tanggalLahirAnak!),
      jenisKelaminAnak: _jenisKelaminAnak,
    );
  }

  String _isoDate(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
}
